<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="styles.css">
<?php
    // Conexión a la base de datos
    $con = mysqli_connect("localhost", "root", "", "plan") or die("ERROR DE CONEXIÓN");

    // Manejar el registro de usuario
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
        $nombre = mysqli_real_escape_string($con, $_POST['nombre']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $contraseña = mysqli_real_escape_string($con, $_POST['contraseña']);
        $tipo = mysqli_real_escape_string($con, $_POST['tipo']);

        // Verificar si el email ya está registrado
        $query = "SELECT * FROM usuarios WHERE email='$email'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) > 0) {
            echo "<script>alert('El email ya está registrado');</script>";
        } else {
            // Insertar el nuevo usuario en la base de datos
            $query = "INSERT INTO usuarios (nombre, email, contraseña, tipo) VALUES ('$nombre', '$email', '$contraseña', '$tipo')";
            if (mysqli_query($con, $query)) {
                echo "<script>alert('Registro exitoso'); window.location.href='usuarios.php';</script>";
            } else {
                echo "<script>alert('Error al registrar');</script>";
            }
        }
    }

    // Manejar la eliminación de usuario
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
        $id = mysqli_real_escape_string($con, $_POST['id']);
        $query = "DELETE FROM usuarios WHERE id='$id'";
        if (mysqli_query($con, $query)) {
            echo "<script>alert('Usuario eliminado'); window.location.href='usuarios.php';</script>";
        } else {
            echo "<script>alert('Error al eliminar');</script>";
        }
    }

    // Manejar la edición de usuario
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit'])) {
        $id = mysqli_real_escape_string($con, $_POST['id']);
        $nombre = mysqli_real_escape_string($con, $_POST['nombre']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $contraseña = mysqli_real_escape_string($con, $_POST['contraseña']);
        $tipo = isset($_POST['tipo']) ? mysqli_real_escape_string($con, $_POST['tipo']) : '';

        $query = "UPDATE usuarios SET nombre='$nombre', email='$email', contraseña='$contraseña', tipo='$tipo' WHERE id='$id'";
        if (mysqli_query($con, $query)) {
            echo "<script>alert('Usuario actualizado'); window.location.href='usuarios.php';</script>";
        } else {
            echo "<script>alert('Error al actualizar');</script>";
        }
    }
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
    <button type="button" onclick="window.location.href='index.html'">Regresar</button>
    <center>
        <h1>Registro de Usuario</h1>
        <form method="POST" action="">
            <input type="text" name="nombre" placeholder="Digite su Nombre" required><br/><br/>
            <input type="email" name="email" placeholder="Digite su Email" required><br/><br/>
            <input type="password" name="contraseña" placeholder="Digite su Contraseña" required><br/><br/>
            <select name="tipo" required>
                <option value="usuario">Usuario</option>
                <option value="proveedor">Proveedor</option>
                <option value="administrador">Administrador</option>
            </select><br/><br/>
            <button type="submit" name="register">Registrar</button>
        </form>
        <h1>Usuarios Registrados</h1>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Contraseña</th>
                <th>Tipo</th>
                <th>Acciones</th>
            </tr>
            <?php
                $query = "SELECT * FROM usuarios";
                $result = mysqli_query($con, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['nombre'] . "</td>";
                    echo "<td>" . $row['email'] . "</td>";
                    echo "<td>" . $row['contraseña'] . "</td>";
                    echo "<td>" . $row['tipo'] . "</td>";
                    echo "<td>
                        <form method='POST' action='' style='display:inline;'>
                            <input type='hidden' name='id' value='" . $row['id'] . "'>
                            <input type='text' name='nombre' value='" . $row['nombre'] . "' required>
                            <input type='email' name='email' value='" . $row['email'] . "' required>
                            <input type='text' name='contraseña' value='" . $row['contraseña'] . "' required>
                            <select name='tipo' required>
                                <option value='usuario'" . ($row['tipo'] == 'usuario' ? ' selected' : '') . ">Usuario</option>
                                <option value='proveedor'" . ($row['tipo'] == 'proveedor' ? ' selected' : '') . ">Proveedor</option>
                                <option value='administrador'" . ($row['tipo'] == 'administrador' ? ' selected' : '') . ">Administrador</option>
                            </select>
                            <button type='submit' name='edit'>Editar</button>
                        </form>
                        <form method='POST' action='' style='display:inline;'>
                            <input type='hidden' name='id' value='" . $row['id'] . "'>
                            <button type='submit' name='delete'>Eliminar</button>
                        </form>
                    </td>";
                    echo "</tr>";
                }
            ?>
        </table>
    </center>
</body>
</html>
