<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="styles.css">
<?php
    // Conexión a la base de datos
    $con = mysqli_connect("localhost", "root", "", "plan") or die("ERROR DE CONEXIÓN");

    session_start();

    // Manejar el inicio de sesión
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $contraseña = mysqli_real_escape_string($con, $_POST['contraseña']);

        $query = "SELECT * FROM usuarios WHERE email='$email' AND contraseña='$contraseña'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) == 1) {
            $_SESSION['email'] = $email;
            header("Location: principal.html");
            exit();
        } else {
            echo "<script>alert('Email o contraseña incorrectos');</script>";
        }
    }
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <button type="button" onclick="window.location.href='index.html'">Regresar</button>
    <center>
        <h1>¡Bienvenido!</h1>
        <form method="POST" action="">
            <input type="text" name="nombre" placeholder="Digite su Usuario" required><br/><br/>
            <input type="email" name="email" placeholder="Digite su Email" required><br/><br/>
            <input type="password" name="contraseña" placeholder="Digite su Contraseña" required><br/><br/>
            <button type="submit">Ingresar</button>
        </form>
    </center>
</body>
</html>