<?php
function generarTablaProductos() {
    $con = mysqli_connect("localhost", "root", "", "plan") or die("ERROR DE CONEXIÓN");

    $query = "SELECT * FROM productos";
    $result = mysqli_query($con, $query);

    echo '<table border="1">';
    echo '<tr>';
    echo '<th>ID</th>';
    echo '<th>Nombre</th>';
    echo '<th>Descripción</th>';
    echo '<th>Precio</th>';
    echo '<th>Cantidad</th>';
    echo '</tr>';

    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . $row['id'] . '</td>';
        echo '<td>' . $row['nombre'] . '</td>';
        echo '<td>' . $row['descripcion'] . '</td>';
        echo '<td>' . $row['precio'] . '</td>';
        echo '<td>' . $row['cantidad'] . '</td>';
        echo '</tr>';
    }

    echo '</table>';
    mysqli_close($con);
}
?>
