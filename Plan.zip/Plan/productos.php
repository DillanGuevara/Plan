<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="styles.css">
<?php
    // Conexión a la base de datos
    $con = mysqli_connect("localhost", "root", "", "plan") or die("ERROR DE CONEXIÓN");

    // Manejar el registro de producto
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create'])) {
        $nombre = mysqli_real_escape_string($con, $_POST['nombre']);
        $descripcion = mysqli_real_escape_string($con, $_POST['descripcion']);
        $precio = mysqli_real_escape_string($con, $_POST['precio']);
        $cantidad = mysqli_real_escape_string($con, $_POST['cantidad']);

        // Insertar el nuevo producto en la base de datos
        $query = "INSERT INTO productos (nombre, descripcion, precio, cantidad) VALUES ('$nombre', '$descripcion', '$precio', '$cantidad')";
        if (mysqli_query($con, $query)) {
            echo "<script>alert('Producto registrado exitosamente'); window.location.href='productos.php';</script>";
        } else {
            echo "<script>alert('Error al registrar producto');</script>";
        }
    }

    // Manejar la eliminación de producto
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
        $id = mysqli_real_escape_string($con, $_POST['id']);
        $query = "DELETE FROM productos WHERE id='$id'";
        if (mysqli_query($con, $query)) {
            echo "<script>alert('Producto eliminado'); window.location.href='productos.php';</script>";
        } else {
            echo "<script>alert('Error al eliminar producto');</script>";
        }
    }

    // Manejar la edición de producto
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit'])) {
        $id = mysqli_real_escape_string($con, $_POST['id']);
        $nombre = mysqli_real_escape_string($con, $_POST['nombre']);
        $descripcion = mysqli_real_escape_string($con, $_POST['descripcion']);
        $precio = mysqli_real_escape_string($con, $_POST['precio']);
        $cantidad = mysqli_real_escape_string($con, $_POST['cantidad']);
        $query = "UPDATE productos SET nombre='$nombre', descripcion='$descripcion', precio='$precio', cantidad='$cantidad' WHERE id='$id'";
        if (mysqli_query($con, $query)) {
            echo "<script>alert('Producto actualizado'); window.location.href='productos.php';</script>";
        } else {
            echo "<script>alert('Error al actualizar producto');</script>";
        }
    }
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Productos</title>
</head>
<body>
    <button type="button" onclick="window.location.href='principal.html'">Regresar</button>
    <center>
        <h1>Registro de Producto</h1>
        <form method="POST" action="">
            <input type="text" name="nombre" placeholder="Nombre del Producto" required><br/><br/>
            <textarea name="descripcion" placeholder="Descripción del Producto" required></textarea><br/><br/>
            <input type="number" step="0.01" name="precio" placeholder="Precio del Producto" required><br/><br/>
            <input type="number" name="cantidad" placeholder="Cantidad del Producto" required><br/><br/>
            <button type="submit" name="create">Registrar Producto</button>
        </form>
        <h1>Lista de Productos</h1>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Acciones</th>
            </tr>
            <?php
                $query = "SELECT * FROM productos";
                $result = mysqli_query($con, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['nombre'] . "</td>";
                    echo "<td>" . $row['descripcion'] . "</td>";
                    echo "<td>" . $row['precio'] . "</td>";
                    echo "<td>" . $row['cantidad'] . "</td>";
                    echo "<td>
                        <form method='POST' action='' style='display:inline;'>
                            <input type='hidden' name='id' value='" . $row['id'] . "'>
                            <input type='text' name='nombre' value='" . $row['nombre'] . "' required>
                            <textarea name='descripcion' required>" . $row['descripcion'] . "</textarea>
                            <input type='number' step='0.01' name='precio' value='" . $row['precio'] . "' required>
                            <input type='number' name='cantidad' value='" . $row['cantidad'] . "' required>
                            <button type='submit' name='edit'>Editar</button>
                        </form>
                        <form method='POST' action='' style='display:inline;'>
                            <input type='hidden' name='id' value='" . $row['id'] . "'>
                            <button type='submit' name='delete'>Eliminar</button>
                        </form>
                    </td>";
                    echo "</tr>";
                }
            ?>
        </table>
    </center>
</body>
</html>
